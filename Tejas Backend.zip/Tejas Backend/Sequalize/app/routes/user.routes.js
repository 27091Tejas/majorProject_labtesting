const { Router } = require("express");
module.exports = app => {
    const labtest=require("../controller/labtest.controllers.js");
    var router=require("express").Router();
}

//create new labtest
